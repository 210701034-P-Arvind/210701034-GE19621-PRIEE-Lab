import './App.css';
import ChatBoxV2 from './components/ChatBoxV2';

function App() {
  return (
    <>
      <ChatBoxV2/>
    </>
  );
}

export default App;
